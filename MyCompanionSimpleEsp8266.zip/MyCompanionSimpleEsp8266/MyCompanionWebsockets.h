#ifndef _MYCOMPANIONWEBSOCKETS_CLIENT_H
#define _MYCOMPANIONWEBSOCKETS_CLIENT_H

#include <MyCompanion_Tiny_websockets/message.hpp>
#include <MyCompanion_Tiny_websockets/client.hpp>
#include <MyCompanion_Tiny_websockets/server.hpp>

#endif //_WEBSOCKETS_CLIENT_H