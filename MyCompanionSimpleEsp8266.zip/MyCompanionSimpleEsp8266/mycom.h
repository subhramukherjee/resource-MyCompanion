/**********************************************************************************************************************************************************************************************
Library for communicating with MyCompanion websockets at https://mycompanion.subhraonline.com 

Brought forward by Subhra K. Mukherjee based on ArduinoWebsockets from GilMeimon


**********************************************************************************************************************************************************************************************/


#ifndef MYCOM_H
#define MYCOM_H
#include<MyCompanionWebsockets.h>
#include <ESP8266WiFi.h>
#include <Base.h>
#include <Handlers.h>

#include<MyTimer.h>
#define MYCOMPANION_DOMAIN "wss://mycompanion.subhraonline.com/MyServ:3111"
#define MYCOMPANION_PORT 3111

void fetchVal(Handlers handlers);
void processAuth(const char* auth);
void recover();

class mycom: public Base {
  private:
    bool connected = false;	
    void connectWiFi(const char* ssid, const char* pass);
    void config();
    bool connect(const char* domain);
	
	void sendMessage(const char* msg, const char* handler);

  public:
	mycom();
	void setConnected(bool con);
	static void processPing();
	//static mycom* getInstance();
    void begin(const char* auth, const char* ssid, const char* pass, const char* domain = MYCOMPANION_DOMAIN, int port = MYCOMPANION_PORT);
    bool isConnected();
    void send(const char* msg, const char* handler);
    void exec();
   
};
typedef mycom Companion;// = mycom();
#endif
