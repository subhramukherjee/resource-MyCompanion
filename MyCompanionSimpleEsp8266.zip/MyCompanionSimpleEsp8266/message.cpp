#include <MyCompanion_Tiny_websockets/message.hpp>

namespace MyCompanion_space { 
  MessageType messageTypeFromOpcode(uint8_t opcode) {
      switch(opcode) {
          case mycom_internals::ContentType::Binary: return MessageType::Binary;
          case mycom_internals::ContentType::Text: return MessageType::Text;
          case mycom_internals::ContentType::Ping: return MessageType::Ping;
          case mycom_internals::ContentType::Pong: return MessageType::Pong;
          case mycom_internals::ContentType::Close: return MessageType::Close;
          default: return MessageType::Empty;
      }
  }
}