/**********************************************************************************************************************************************************************************************
Library for communicating with MyCompanion websockets at https://mycompanion.subhraonline.com 

Brought forward by Subhra K. Mukherjee based on ArduinoWebsockets from GilMeimon


**********************************************************************************************************************************************************************************************/

#ifndef MYCOMPANIONSIMPLEESP8266_H
#define MYCOMPANIONSIMPLEESP8266_H
//#include "defines.h"
#include<String.h>
#include <mycom.h>



//long t = millis();
//mycom MyCompanion;

Companion MyCompanion;// = Companion:: getInstance();

#endif
