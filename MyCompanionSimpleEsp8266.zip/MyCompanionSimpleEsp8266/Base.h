
#ifndef BASE_H
#define BASE_H
#include<ArduinoWebsockets.h>
#include <ESP8266WiFi.h>


#if (ESP8266)
  #define BOARD_TYPE      "ESP8266"
#else
  #error This code is intended to run only on the ESP8266 boards ! Please check your Tools->Board setting.
#endif

#ifndef BOARD_NAME
  #define BOARD_NAME    BOARD_TYPE
#endif

#define DEBUG_WEBSOCKETS_PORT     Serial
// Debug Level from 0 to 4
#define _WEBSOCKETS_LOGLEVEL_     3

class Base{
	private:
		//virtual String getMessage(String data) = 0;
    
  public:
    
};
#endif
