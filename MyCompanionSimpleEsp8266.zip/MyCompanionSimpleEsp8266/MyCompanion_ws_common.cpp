#include "MyCompanion_Tiny_websockets/internals/ws_common.hpp"

namespace MyCompanion_space { namespace mycom_internals {
    WSString fromInterfaceString(const WSInterfaceString& str) {
        return str.c_str();
    }
    WSString fromInterfaceString(const WSInterfaceString&& str) {
        return str.c_str();
    }

    WSInterfaceString fromInternalString(const WSString& str) {
        return str.c_str();
    }
    WSInterfaceString fromInternalString(const WSString&& str) {
        return str.c_str();
    }
}}
