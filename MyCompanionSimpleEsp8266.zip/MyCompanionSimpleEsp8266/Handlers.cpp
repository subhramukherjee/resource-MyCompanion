/**********************************************************************************************************************************************************************************************
Library for communicating with MyCompanion websockets at https://mycompanion.subhraonline.com 

Brought forward by Subhra K. Mukherjee based on ArduinoWebsockets from GilMeimon


**********************************************************************************************************************************************************************************************/
#include "Handlers.h"
Handlers:: Handlers(){
      
    }
void Handlers:: setStringandParse(String rcv){
	recv = rcv;
    parseMessage("",recv);///////////////////////////
}
String Handlers:: getVal(String handle){
     return parseMessage(handle, recv);
}
String Handlers:: getQVal(){
  return this->qVal;
}
String Handlers:: getMVal(){
  return this->mVal;
}
bool Handlers:: isFetchable(){
	return this->fetchable;
}
//below should be void
String Handlers:: parseMessage(String handle, String recv){
  this->qVal = "xx";
  this->mVal = "xx";
  //Serial.println("THE RECEIVED ::"+recv);
   if(!(recv.length()>0)) return "Returned null";
      const size_t capacity = JSON_OBJECT_SIZE(3) + 480;  // + JSON_ARRAY_SIZE(2) + 60;
      //DynamicJsonDocument doc(capacity);
      StaticJsonDocument<capacity> doc;
      // Parse JSON object
      DeserializationError error = deserializeJson(doc, recv);
      if (error) {
        Serial.print(F("deserializeJson() failed: "));
        Serial.println(error.c_str());
        return "ERROR";
      }
      if(recv.indexOf("RONLINE") >=0 || recv.indexOf("OFFLINE") >=0){
         if(strcmp(doc["message"], "RONLINE") == 0){
			 if(!(this->doOnceRAction)){
				this->fetchable = false;
				return "no value";				
			 }
			 this->fetchable = true;
            this->mVal = "REMOTE ONLINE";
            this->qVal = "";
			this->doOnceRAction = false;
            return "REMOTE ONLINE";
         }else{
			if(this->doOnceRAction){
				this->fetchable = false;
				return "no value";
			}
			this->fetchable = true;
            this->mVal = "REMOTE OFFLINE";
            this->qVal = "";
			this->doOnceRAction = true;
            return "OFFLINE";
         }
         //return "Bad command";
    }else if(recv.indexOf("pong") >=0){
      Serial.println(doc["pong"].as<char*>());
      return "pong";
    }else{
      //if(recv.indexOf(handle) <0) return "Wrong Handler";////check should be there
      //Serial.println(doc["message"].as<char*>());
      if(recv.indexOf("handler") <0){
        const char* stat = 0;
        stat = doc["status"];
        if(stat == 0) stat = doc["stat"];
        if( strlen(stat)>0 && strcmp(stat,"online") == 0){
			if(!(this->doOnceMAction)){
				this->fetchable =false;
				return "no value";
			}
			this->fetchable = true;
          this->mVal = "ME ONLINE";
		  this->doOnceMAction = false;
          return "ONLINE";
        }else{
			if(this->doOnceMAction){
				this->fetchable = false;
				return "no value";
			}
			this->fetchable = true;
          this->mVal = "ME OFFLINE";
		  this->doOnceMAction = true;
          return "OFFLINE";
        }
      }else{
          String str = doc["handler"];    //check should be there //doc[handle];
          String mv = doc["message"];    //check should be there
          if(str.length()>0){
			  //this->fetchable = true;
			  this->qVal = str;
          }else{
			  this->qVal = "";
		  }
          if(mv.length()>0) this->mVal = mv;
          else this->mVal = "";
		  if(qVal.length()>0 && mVal.length()>0){
			  this->fetchable = true;
		  }else this->fetchable = false;
          //Serial.println("THE RECEIVED ::"+str);
          if(str.length() == 0){
            return "Wrong Handler";
          } else{
             //Serial.println("THE RECEIVED ::NOT NULL");
            return str;
          }
        }
        //Serial.println(recv);
        //return recv;
        
      }
      //digitalWrite(13 , HIGH);  //D7 pin of nodemcu
      
      //else if(str.isEmpty())return "Wrong Handler123";
     doc.clear();
    }
