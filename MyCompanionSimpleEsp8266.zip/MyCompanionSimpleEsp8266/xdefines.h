
#ifndef DEFINES_H
#define DEFINES_H
#define PICK1 "pick1"
#define PICK2 "pick2"
#define PICK3 "pick3"
#define PICK4 "pick4"
#define PICK5 "pick5"
#define PICK6 "pick6"
#define PICK7 "pick7"
#define PICK8 "pick8"
#define PICK9 "pick9"
#define PICK10 "pick10"
#define PICK11 "pick11"
#define PICK12 "pick12"
/*#include "mycom.h"
#if (ESP8266)
  #define BOARD_TYPE      "ESP8266"
#else
  #error This code is intended to run only on the ESP8266 boards ! Please check your Tools->Board setting.
#endif

#ifndef BOARD_NAME
  #define BOARD_NAME    BOARD_TYPE
#endif

#define DEBUG_WEBSOCKETS_PORT     Serial
// Debug Level from 0 to 4
#define _WEBSOCKETS_LOGLEVEL_     3*/

//const mycom MYCOMP;

//const char* ssid = "super123"; //Enter SSID
//const char* password = "skjeexx123098"; //Enter Password

//const char* websockets_connection_string = "wss://echo.websocket.org/"; //Enter server adress
const char* websockets_connection_string = "wss://mycompanion.subhraonline.com/MyServ:3111"; //Enter server adress

// To update SHA1 fingerprint, use Google Chrome to connect to https://www.websocket.org/echo.html 
// Then "View Site Information" => "Certificate Viewer" => Copy SHA1 fingerprint
// This latest SHA1 fingerprint was updated 13.07.2020
//const char echo_org_ssl_fingerprint[] = "F0 DC 2E 40 A6 6D 29 B5 73 8F E1 E8 A9 EA 2A 9B 50 68 80 E3";
//const char echo_org_ssl_fingerprint[] PROGMEM   = "ade0b36be5bd3dcfc093371e85e62a408462f396";
const char echo_org_ssl_fingerprint[] = "991cd7aaad9c33b4c72338877e61d63d78c742fb";

#endif      //defines_h
