/**********************************************************************************************************************************************************************************************
Library for communicating with MyCompanion websockets at https://mycompanion.subhraonline.com 

Brought forward by Subhra K. Mukherjee based on ArduinoWebsockets from GilMeimon


**********************************************************************************************************************************************************************************************/

#include <mycom.h>
using namespace MyCompanion_space;           
	MyWebsocketsClient client;
void onEventsCallback(WebsocketsEvent event, String data);
void onMessageCallback(WebsocketsMessage message);
bool isSend = false;
const char *toSend;
const char* qHandler;
const char* _token; 
const char echo_org_ssl_fingerprint[] = "991cd7aaad9c33b4c72338877e61d63d78c742fb";
bool doConnect = false;
const char* _domain;
const char* _ssid;
const char* _pass;
Handlers handlers;
//using namespace MyCompanion_Timer;
MyTimer tickerx;
mycom:: mycom(){
    //this->Companion = ;
    //mycom:: HASINSTANCE = true;
	//this->handlers = Handlers:: Handlers();
  }
	
void mycom:: connectWiFi(const char* ssid, const char* pass){
  Serial.println(strcat("Connecting to ",ssid));
        WiFi.mode(WIFI_STA);
        if (WiFi.status() != WL_CONNECTED) {
            if (pass && strlen(pass)) {
                WiFi.begin(ssid, pass);
            } else {
                WiFi.begin(ssid);
            }
        }
        while (WiFi.status() != WL_CONNECTED) {
            Serial.print(".");
            delay(500);
        }
        Serial.println(F("Connected to WiFi"));
        IPAddress myip = WiFi.localIP();
        Serial.println("IP: "+myip);
}

void mycom:: begin(const char* auth,const char* ssid, const char* pass, const char* domain, int    port){
      unsigned int free_heap_before = ESP.getFreeHeap();
      unsigned int free_stack_before = ESP.getFreeContStack();
	  //MyCompanion = Companion:: getInstance();
      _token = auth;
	  _domain = domain;
	  _ssid = ssid;
	  _pass = pass;
      //if(!INSTANCE){
        this->connectWiFi(ssid, pass);
        this->config();
        int numConnect = 0;
		//Serial.println("YES..");
		//this->connect();
        while((connected = this->connect(domain)) != true) {
          //numConnect++;
          Serial.println("Trying to connect to MyCompanion");
        }
       Serial.println("Connected!");
       //processAuth(auth);

    }
	
bool mycom:: isConnected(){return connected;}
void mycom::config(){
        client.onMessage(onMessageCallback);
        // run callback when events are occuring
        //client.onEvent(&Callback_tt ::onEventsCallback);
        client.onEvent(onEventsCallback);

        // Before connecting, set the ssl fingerprint of the server
       client.setFingerprint(echo_org_ssl_fingerprint);
       client.setInsecure();

       // client.setFingerprint(echo_org_ssl_fingerprint);
        //this->begin(domain);
    }
	
bool mycom:: connect(const char* domain){
	Serial.println("Connecting..");
      bool connected = client.connect(domain); 
	  doConnect = true;
      return connected;
    }
	
void mycom::send(const char* msg, const char* handler){
  isSend = true;
  toSend = msg;
  qHandler = handler;
}

void mycom::exec(){
      client.poll();
      //processPing();
      //if(this->isConnected()) processPing();
	  recover();
      if(isSend){
        isSend = false;
        sendMessage(toSend, qHandler);
      }
}

void mycom:: setConnected(bool con){
	this->connected = con;
}
void recover(){
	if(!doConnect){
		if (WiFi.status() != WL_CONNECTED) {
            if (_pass && strlen(_pass)) {
                WiFi.begin(_ssid, _pass);
            } else {
                WiFi.begin(_ssid);
            }
        }
        while (WiFi.status() != WL_CONNECTED) {
            Serial.print(".");
            delay(500);
        }
        Serial.println(F("Connected to WiFi"));
        IPAddress myip = WiFi.localIP();
        Serial.println("IP: "+myip);
		doConnect = client.connect(_domain);
	}
}
void onMessageCallback(WebsocketsMessage message) 
{
	doConnect = true;
  //Serial.print("Got Message: ");
  String msg = message.data();
  //Serial.println(msg);
  //setMessage(&msg);
  //received = msg;
  if(!(msg.indexOf("pong") >=0)){
    //Serial.print("Got Message: ");Serial.println(msg);
    //Handlers handlers(msg);
	handlers.setStringandParse(msg);
	if(handlers.isFetchable()) fetchVal(handlers);
  }else{
    //Serial.println(msg);
    //client.ping();
  }
  //MYHANDLER.setVal(msg);
  //HANDLER.setVal(msg);
  //t = millis();
}

void onEventsCallback(WebsocketsEvent event, String data) 
{
  if (event == WebsocketsEvent::ConnectionOpened) 
  {
    client.send("{\"ping\":\"ok\"}");
    //Serial.println(F$("Connnection Opened"));
    //using :: mycom;
    if(_token) processAuth(_token);
	//auth.process(_token);
    tickerx.attach_scheduled(4, mycom::processPing);
  } 
  else if (event == WebsocketsEvent::ConnectionClosed) 
  {
	doConnect = false;
    Serial.println("Connnection Closed");
  } 
  else if (event == WebsocketsEvent::GotPing) 
  {
    Serial.println("Got a Ping!");
  } 
  else if (event == WebsocketsEvent::GotPong) 
  {
    Serial.println("Got a Pong!");
  }else{
	  doConnect = false;
    Serial.print("Error: ");
  }
}

void processAuth(const char* auth){
    //const size_t capacity = JSON_OBJECT_SIZE(3);
    const size_t capacity = JSON_OBJECT_SIZE(3)+ JSON_ARRAY_SIZE(70);  // + JSON_ARRAY_SIZE(2) + 60;
    //DynamicJsonDocument doc(capacity);
    StaticJsonDocument<capacity> doc;
    doc["token"] = auth;
    doc["intent"] = "join";
    doc["text"] = "esp8266-subhra";
    String WS_msg;
    serializeJson(doc, WS_msg);
    client.send(WS_msg);
    doc.clear();
}
void mycom:: processPing(){
  //if(millis() - t > 4000){
    const size_t capacity = JSON_OBJECT_SIZE(1)+10;  
    //DynamicJsonDocument doc(capacity);
    StaticJsonDocument<capacity> doc;
    doc["ping"] = "ok";
    String WS_msg;
    serializeJson(doc, WS_msg);
    client.send(WS_msg);
    //Serial.println("sent :"+WS_msg);
    digitalWrite(13, LOW);  //D7 pin of nodemcu
   // t = millis();
  //}
}
void mycom:: sendMessage(const char* msg, const char* handler){
    //if(!client.isConnected()) return;
    const size_t capacity = JSON_OBJECT_SIZE(3)+200;
    StaticJsonDocument<capacity> doc;
    //DynamicJsonDocument docx(capacity);
    doc["text"] = msg;   //"message back from esp:: ONLINE";
    doc["agent"] = "esp8266";
    doc["intent"] = "send";
    doc["handler"] = handler;
    
    String WS_msg;
    serializeJson(doc, WS_msg);
    //docx.clear();
    //Serial.println("sending..."+WS_msg);
    client.send(WS_msg);
    //client.send(msg);
}
typedef mycom Companion;
