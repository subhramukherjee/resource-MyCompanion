/**********************************************************************************************************************************************************************************************
Library for communicating with MyCompanion websockets at https://mycompanion.subhraonline.com 

Brought forward by Subhra K. Mukherjee based on ArduinoWebsockets from GilMeimon


**********************************************************************************************************************************************************************************************/
#ifndef HANDLERS_H
#define HANDLERS_H
#include "ArduinoJson.h"
class Handlers{
  private:
    String recv;
    String qVal;
    String mVal;
	bool fetchable = false;
	bool doOnceRAction = true;
	bool doOnceMAction = true;
    String parseMessage(String, String);
    //vector v;
  public:
    Handlers();
	void setStringandParse(String rcv);
	bool isFetchable();
    String getVal(String handle);
    String getQVal();
    String getMVal();
};
#endif