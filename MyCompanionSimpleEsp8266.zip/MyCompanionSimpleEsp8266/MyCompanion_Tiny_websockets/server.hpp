#pragma once

#include <MyCompanion_Tiny_websockets/internals/ws_common.hpp>
#include <MyCompanion_Tiny_websockets/client.hpp>
#include <functional>

namespace MyCompanion_space {
  class WebsocketsServer {
  public:
    WebsocketsServer(network::TcpServer* server = new WSDefaultTcpServer);
    
    WebsocketsServer(const WebsocketsServer& other) = delete;
    WebsocketsServer(const WebsocketsServer&& other) = delete;
    
    WebsocketsServer& operator=(const WebsocketsServer& other) = delete;
    WebsocketsServer& operator=(const WebsocketsServer&& other) = delete;

    bool available();
    void listen(uint16_t port);
    bool poll();
    MyWebsocketsClient accept();

    virtual ~WebsocketsServer();

  private:
    network::TcpServer* _server;
  };
}